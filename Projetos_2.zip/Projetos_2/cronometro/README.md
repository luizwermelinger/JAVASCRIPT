# Cronômetro

### Descrição

- App Cronômetro permite que o usuario marque o tempo de forma rápida e precisa
- O projeto conta com os botões Start, Stop e Reset.

<div align="center">
    <p> &copy; Guilherme Amaral - 2023 </p>
</div>