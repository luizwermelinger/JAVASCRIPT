# Boas vindas aos mini projetos!

### Descrição

- Projetos simples desenvolvidos com html, css e javascript
- Todos os mini projetos estão hospedados aqui no GitHub e você pode acessá-los
na página principal criada para redirecionar os projetos ou alterando a url para
o nome exato do repositório.
- Todos os mini projetos estão sendo constantemente atualizados e construídos,
então não fique triste se um deles não estiver do jeito que estava da última vez
que você viu.
- Colabore com o desenvolvimento caso exista algum [bug](https://github.com/Guimrl/mini-projetos/issues/new).

### Exemplo:

<p><img src="https://user-images.githubusercontent.com/88007295/215334851-83803231-a595-42eb-b109-89c4f6fb7bad.png"></p>

### Status

- Em desenvolvimento.

### License

- GNU GENERAL PUBLIC LICENSE v3

<br>
<hr>

<div align="center">
    <img align="center" width='120px' src='https://user-images.githubusercontent.com/88007295/209672251-8a43d046-4dfb-44fe-b154-5b4d0f1e13b1.png'/>
</div>

<div align="center">
    	&copy; Touro Manco Produções - 2023
</div>