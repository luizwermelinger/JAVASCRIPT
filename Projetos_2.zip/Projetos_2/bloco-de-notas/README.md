# Bloco de Notas

### Descrição

- Mini projeto de um bloco de notas é uma aplicação CRUD(Create, Read, Update, Delete).

- Permite que o usuário crie, edite, remova e leia as notas no futuro.

<div align="center">
    <p> &copy; Guilherme Amaral - 2023 </p>
</div>