# Mouse Tracker

### Descrição

- Exemplo de Mouse Tracking desenvolvido com html, css e javascript
- Sim, eu amo patos.

### Exemplo:

<p><img src="./img/exemplo.jpg"></p>