# Encurtador de URL

### Descrição

- Encurte sua URL de forma rápida e simples fornecendo apenas uma url como parametro.
- O projeto consome a API da rebrandly e você pode saber mais sobre no [link](https://rebrandly.com/) ou em https://rebrandly.com/

<hr>
<div align="center">
    <p> &copy; Guilherme Amaral - 2023 </p>
</div>