/*
        Usado para potencias exp: 5 ao cubo = 125 ou 5x5x5 = 125

*/
const result = Math.pow(5,3)
console.log(result)

/*
        Usado para raizes exp: 25 raiz de 2 = 5 ou 25/5 = 5

*/
const resulta = Math.sqrt(25,2)
console.log(resulta)

/*
        Usado para valores de Pi ou seja 3,14...

*/
const resultb = Math.PI
console.log(resultb)

/*
        Usado para arredondar para cima exp : 3,145 vira = 4

*/
const resultc = Math.ceil(3.14)
console.log(resultc)

/*
        Usado para arredondar para baixo exp : 3,145 vira = 3

*/
const resultd = Math.floor(3.14)
console.log(resultd)

/*
        Usado para números aleatórios entre 0 e 1

*/
const resulte = Math.random()
console.log(resulte)