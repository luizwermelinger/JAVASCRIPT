


const variable = "Abacateiro"
    console.log(variable)

function nomeNaTela(){
    console.log(Magno)
}

nomeNaTela()