
//Exemplo de null:

let nome = null; // Atribuindo o valor 'null' a uma variável
console.log(nome); // Saída: null
console.log(typeof nome); // Saída: object (um bug na implementação do typeof para null)

//Exemplo de undefined:

let idade; // Declaração da variável sem atribuição
console.log(idade); // Saída: undefined
console.log(typeof idade); // Saída: undefined