//Criar um array com valores.

    let frutas = ["maçã", "banana", "laranja"];
    console.log(frutas); // Saída: ["maçã", "banana", "laranja"]

//Criar um array vazio.

    let vazio = [];
    console.log(vazio); // Saída: []

//Criar um array com o construtor Array():

    let numeros1 = new Array(10, 20, 30);
    console.log(numeros1); // Saída: [10, 20, 30]

//Adicionar elementos a um array.

    let cores = ["vermelho"];
    cores.push("azul"); // Adiciona "azul" ao final
    cores.unshift("amarelo"); // Adiciona "amarelo" ao início
    console.log(cores); // Saída: ["amarelo", "vermelho", "azul"]

//Acessar elementos de um array.

    let numeros = [1, 2, 3];
    console.log(numeros[0]); // Saída: 1 (o primeiro elemento)
    console.log(numeros[2]); // Saída: 3 (o terceiro elemento)

//Obter o tamanho de um array.

    let frutas1 = ["maçã", "banana", "laranja"];
    console.log(frutas1.length); // Saída: 3