
const number1 = 32 / 2
const fakeNumber = "32 / 2"

console.log(number1)
console.log(fakeNumber)

let maiorNum = Number.MAX_VALUE; //Valor máximo
let menorNum = Number.MIN_VALUE; //Valor mínimo
let infiniteNum = Number.POSITIVE_INFINITY; //Infinito positivo
let negInfiniteNum = Number.NEGATIVE_INFINITY; //Infinito negativo
let notANum = Number.NaN; //Não é numeral
