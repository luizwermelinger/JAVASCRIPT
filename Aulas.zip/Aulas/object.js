const pessoa = {
    nome: "João",          // Propriedade "nome" com o valor "João"
    idade: 30,          // Propriedade "idade" com o valor 30
    cidade: "Lisboa",     // Propriedade "cidade" com o valor "Lisboa"
    saudacao: function() { // Método "saudacao" que retorna uma saudação
      return "Olá, meu nome é " + this.nome + "!";
    }
  };
  
  console.log(pessoa.nome);       // Saída: João
  console.log(pessoa.idade);      // Saída: 30
  console.log(pessoa.saudacao());   // Saída: Olá, meu nome é João!
  
  // Acessar propriedades usando colchetes:
  console.log(pessoa["cidade"]);  // Saída: Lisboa


  // Objeto vazio
const vazio = {};

// Objeto com um array
const dados = {
  nomes: ["Ana", "Carlos", "Maria"],
  idades: [25, 30, 28]
};

// Objeto aninhado (objeto dentro de outro objeto)
const endereco = {
  rua: "Rua Principal",
  numero: 123,
  cidade: "Rio de Janeiro"
};

const pessoaComEndereco = {
  nome: "João",
  endereco: endereco
};

console.log(pessoaComEndereco.endereco.rua); // Saída: Rua Principal

