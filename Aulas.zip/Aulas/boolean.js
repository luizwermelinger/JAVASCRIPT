/*
        basicamente comunicação de máquinas é baseado em 0 e 1
        ou falso e verdadeiro
        false / true

*/

// Declarando variáveis booleanas
let ligado = true; // A luz está ligada
let desativado = false; // O botão está desativado

// Usando booleanos em comparações
if (ligado) {
  console.log("A luz está ligada.");
} else {
  console.log("A luz está desligada.");
}

// Usando booleanos em expressões lógicas
let usuarioAutenticado = true;
let temPermissao = false;

if (usuarioAutenticado && temPermissao) {
  console.log("Usuário autenticado e com permissão.");
} else {
  console.log("Usuário não autenticado ou sem permissão.");
}

// Conversão implícita para booleano
let numero = 0; // Valor falsy
if (!numero) {
  console.log("O número é considerado falso.");
}

numero = 5; // Valor truthy
if (numero) {
  console.log("O número é considerado verdadeiro.");
}

// Objetos Boolean (evitar)
let meuObjeto = new Boolean(true); // Cria um objeto Boolean
console.log(meuObjeto.valueOf()); // Retorna true (valor primitivo)
console.log(typeof meuObjeto); // Retorna "object" (tipo do objeto)

// É preferível usar valores booleanos primitivos diretamente
meuObjeto = true;
console.log(meuObjeto); // Retorna true (valor primitivo)
console.log(typeof meuObjeto); // Retorna "boolean" (tipo booleano)