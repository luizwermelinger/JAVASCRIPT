/*
            Veja a tabela abaixo:

            Operador	Operação	Exemplo

            >	Maior que	(a > b)
            <	Menor que	(a < b)
            >=	Maior ou igual a	(a >= b)
            <=	Menor ou igual a	(a <= b)
            ==	Igual a	(a == b)
            !=	Diferente de	(a !== b)
            ===	Idêntico a	(a === b)
            !==	Não idêntico a	(a !== b)
            &&	E/and	(a && b)
            ll 	Ou/or	(a ll b)

*/

const firstNumber = 50
const secondNumber = 17

if (firstNumber == secondNumber){
    console.log("Eles são iguais")
} else {
    console.log("Eles não são iguais")
}