/*
        if = (se)
        else (se não) 

        Operações de comaparação

        > maior que
        < menor que
        == igual que

*/

const notaDoAluno = 7
const notaDeCorte = 5

if (notaDoAluno > notaDeCorte){
        console.log("Parabéns você conseguiu")  //VERDADEIRO 7 > 5 ,do contrário seria exp: 3 > 5

        // O que será executado se (if) for verdadeiro
}   else{
    console.log("Você não fez o que deveria")
    // se o (if) for falso ele entra aki
    
}
