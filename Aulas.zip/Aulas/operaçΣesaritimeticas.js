// Adição (+)

let somaNumeros = 5 + 3; // 8
let somaStrings = "Olá " + "Mundo"; // "Olá Mundo"

// Subtração (-)

let diferenca = 10 - 5; // 5
let numeroNegativo = -5;

// Multiplicação (*)

let produto = 4 * 3; // 12

// Divisão (/)

let quociente = 20 / 5; // 4
let divisaoPorZero = 5 / 0; // Infinity

// Módulo (%)

let resto = 7 % 3; // 1

// Incremento (++) e Decremento (--)

let contador = 0;
contador++;
contador--; // Volta a 0

// Atribuição com Adição (+=)

let total = 10;
total += 5; // total é 15

// Atribuição com Subtração (-=)

let saldo = 10;
saldo -= 5; // saldo é 5

// Atribuição com Multiplicação (*=) e Divisão (/=)

let produtoA = 10;
produtoA *= 2; // produto é 20

let divisao = 20;
divisao /= 2; // divisao é 10

// Cálculo da Média

let nota1 = 7.5, nota2 = 8.0, nota3 = 9.5;
let media = (nota1 + nota2 + nota3) / 3;
console.log("Média: " + media.toFixed(2)); // "Média: 8.33"

// Trabalhando com Percentuais

let preco = 100;
let desconto = 15; // 15%
let precoComDesconto = preco * (1 - desconto / 100);
console.log("Preço com desconto: " + precoComDesconto); // 85



