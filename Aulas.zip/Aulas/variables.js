
/*
        let = pode alterar o valor quando quiser
        const = o valor nao poder ser alterado exp: 1 abacate nãp poderá ser 2 abacates
        var = código descontinuado "não é mais utilizado"

        ctrl + alt = n = rodar o javascript

        1 ) string = textos como que usa 
        "aqui dentro! das aspas duplas" 
               ou com aspas simples 
        'aqui dentro os textos!'
              e ainda com crase
        `aqui dentro os textos!`

        Obs: crase permite pular linhas diferente das aspas!

*/

const myAge = 40
const myCar = `Gol`

const myString = `Minha idade é ${10 + 30}, estou ficando idoso
mas estou andando de ${myCar} `

console.log(myString)